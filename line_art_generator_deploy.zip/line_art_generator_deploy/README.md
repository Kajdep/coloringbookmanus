# Line Art Coloring Book Generator

A web application that generates line art coloring book images with a focus on office interiors in Apple + Severance diorama style.

## Features

- Clean line art generation for coloring books
- Batch processing of up to 60 images
- Customization options for line thickness, text, resolution, and margins
- Multiple model options for different line art styles

## Deployment

This application is configured for deployment on Render.com.

### Requirements

- Stability AI API key

### Environment Variables

- `STABILITY_API_KEY`: Your Stability AI API key

## Local Development

1. Install dependencies: `pip install -r requirements.txt`
2. Run the application: `python wsgi.py`
3. Access at http://localhost:5000
